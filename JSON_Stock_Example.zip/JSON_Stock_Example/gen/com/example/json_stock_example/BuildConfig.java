/** Automatically generated file. DO NOT MODIFY */
package com.example.json_stock_example;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}